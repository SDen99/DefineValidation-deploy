import{a$ as s,b0 as o}from"../chunks/DBULfDCC.js";export{s as load_css,o as start};
