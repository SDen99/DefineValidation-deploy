import{a_ as s,a$ as a}from"../chunks/zlWF3IZ4.js";export{s as load_css,a as start};
